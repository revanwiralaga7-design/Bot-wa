# XDBOTZ MD — Panduan Tambah Fitur

Dokumen ini **di-upload ke ChatGPT / Claude / AI cloud**.  
Fungsinya: AI paham struktur bot XDBOTZ MD, lalu **nanya ke kamu** mau buat fitur apa — kamu jelasin sendiri, AI yang bantu bikin kodenya.

> **Bot:** XDBOTZ MD (WhatsApp automation)  
> **Stack:** Node.js ≥ 20, Baileys (`@Kurniaharun/Baileys`), JSON file DB  
> **Entry point:** `index.js`  
> **Developer:** KurrXd

---

## 1. Alur kerja (yang dipakai)

```
1. Upload file CARA-TAMBAH-FITUR.md ke AI cloud
2. AI baca panduan → paham struktur bot
3. AI TANYA: "Mau tambah fitur apa?"
4. Kamu JELASIN sendiri (command, fungsi, siapa boleh pakai, dll.)
5. AI buat/edit file sesuai panduan di bawah
6. Kamu copy hasil ke project → restart bot → tes
7. Kalau error / aneh → balik ke Cursor atau paste error ke AI cloud
```

**Kamu tidak perlu** suruh AI baca full script.  
**Kamu tidak perlu** tulis prompt panjang di awal — cukup upload MD ini, AI yang mulai nanya.

### Upload pertama — prompt singkat (opsional)

Kalau AI belum otomatis nanya, tempel ini:

```
Baca CARA-TAMBAH-FITUR.md.
Kamu asisten developer XDBOTZ MD (WhatsApp bot Node.js).

Tanyain dulu ke saya:
- Mau fitur apa?
- Command & prefix?
- Siapa boleh pakai?
- Input/output seperti apa?

Baru setelah saya jawab, buatkan file + edit registry, handlers, config.
Ikuti konvensi di MD. Jangan sentuh connection/session kecuali diminta.
```

---

## 2. Instruksi untuk AI cloud (WAJIB dibaca AI)

Kalau kamu AI yang menerima file ini:

1. **Jangan langsung coding** — tanya dulu ke user fitur yang diinginkan.
2. **Tanya minimal:**
   - Nama command & alias (contoh: `.giveaway`, alias `gw`)
   - Fungsi / apa yang dilakukan
   - Siapa boleh pakai (semua user / owner only / admin grup / grup saja)
   - Format input (args, reply media, link, dll.)
   - Format output (teks biasa / box formatter / media)
   - Perlu API eksternal? (OpenAI, scrape, cloud, dll.)
3. **Setelah user jawab** — buat perubahan minimal:
   - File command baru di `src/commands/`
   - Edit `registry.js`, `handlers.js`, `config.json`
   - Logic berat di `src/lib/` (file baru jika perlu)
4. **Jangan ubah** tanpa diminta: `handlers/connection/`, `session/`, `node_modules/`, `credit.js`
5. **Match style:** CommonJS, `'use strict'`, bahasa UI Indonesia
6. **Selesai coding** — beri checklist test + perintah `node --check` file baru

---

## 3. Alur pesan (message flow)

```
WhatsApp
  → Baileys socket (messages.upsert)
  → src/handlers/message.js
  → src/lib/message-parser.js (buildContext)
  → Apakah command? (ada prefix + nama command)
  → src/handlers/command.js (dispatchCommand)
  → src/commands/general|group|owner/<nama>.js
  → src/lib/messaging.js (sendBotReply / sendBotText)
  → Balas ke chat
```

**Event lain (bukan command):**
- Member join grup → `src/handlers/group-participants.js` → `src/handlers/welcome.js`
- Panggilan masuk → `src/handlers/call.js`
- Koneksi/QR → `src/handlers/connection/`

---

## 4. Struktur folder penting

```
BotWhatsappScript/
├── index.js                    # Start bot
├── config.json                 # Konfigurasi utama
├── docs/
│   └── CARA-TAMBAH-FITUR.md   # File ini
├── data/                       # JSON DB (user, group, runtime)
├── session/                    # Session WhatsApp (JANGAN commit)
├── logs/
└── src/
    ├── commands/
    │   ├── index.js            # Resolver command
    │   ├── registry.js         # Daftar metadata command ★
    │   ├── handlers.js         # Wire handler ke file ★
    │   ├── general/            # Command umum (ping, help, sticker…)
    │   ├── group/              # Command khusus grup (welcome)
    │   └── owner/              # Command owner (self, public)
    ├── handlers/
    │   ├── message.js          # Terima semua pesan
    │   ├── command.js          # Dispatch command
    │   └── connection/         # Koneksi Baileys
    └── lib/
        ├── config.js           # loadConfig(), saveRuntime()
        ├── formatter.js        # Template teks box menu
        ├── messaging.js        # sendBotReply, replyOptions
        ├── permissions.js      # canRunCommand, shouldProcessInGroup
        ├── message-parser.js   # buildContext, parse command
        ├── jid.js              # Helper JID/phone
        ├── db/                 # users, groups, calls (JSON)
        └── credit.js           # Footer "KurrXd Official"
```

**★ = wajib edit setiap tambah command baru**

---

## 5. Checklist tambah command (4 langkah)

### Langkah 1 — Buat file handler

| Tipe | Lokasi file |
|------|-------------|
| Command umum (DM + grup) | `src/commands/general/<nama>.js` |
| Command khusus grup | `src/commands/group/<nama>.js` |
| Command owner only | `src/commands/owner/<nama>.js` |

Template minimal:

```javascript
'use strict';

const { sendBotReply } = require('../../lib/messaging');
const { buildGroupOnlyText } = require('../../lib/formatter');

module.exports = async function namaCommand(ctx, kurrxd) {
  // Opsional: hanya grup
  // if (!ctx.isGroup) {
  //   await sendBotReply(kurrxd, ctx, { text: buildGroupOnlyText('nama') });
  //   return;
  // }

  const input = ctx.args.join(' ').trim();

  if (!input) {
    await sendBotReply(kurrxd, ctx, {
      text: 'Format: `.nama <argumen>`'
    });
    return;
  }

  // Logic fitur di sini

  await sendBotReply(kurrxd, ctx, { text: `Hasil: ${input}` });
};
```

**Signature handler:** `async function(ctx, kurrxd, deps)`

- `ctx` — context pesan (lihat bagian 5)
- `kurrxd` — socket Baileys (kirim pesan, groupMetadata, dll.)
- `deps` — opsional: `{ logger, setRuntime, getRuntime, startedAt, botJid }`

---

### Langkah 2 — Daftar di `src/commands/registry.js`

```javascript
{
  name: 'giveaway',           // nama utama (lowercase)
  aliases: ['gw', 'cekgw'],   // alias opsional
  category: 'general',        // general | group | owner
  ownerOnly: false,           // true = cuma owner
  description: 'Cek giveaway' // untuk dokumentasi (menu tidak tampilkan deskripsi)
}
```

**Catatan fitur mode:** command `self` dan `public` pakai key `mode` di config features.

---

### Langkah 3 — Wire di `src/commands/handlers.js`

```javascript
giveaway: require('./general/giveaway'),
```

Nama property **harus sama** dengan `name` di registry.

---

### Langkah 4 — Aktifkan di `config.json`

```json
"features": {
  "giveaway": true
}
```

Key = `name` command, kecuali `self`/`public` → key `"mode"`.

---

### Selesai — Restart & test

```bash
node index.js
```

Test di WhatsApp:
- DM: `.giveaway test`
- Grup: `.giveaway test` (grup wajib pakai prefix jika `group.requirePrefix: true`)

Command otomatis muncul di `.help` / `.menu`.

---

## 6. Object `ctx` (context pesan)

Dibuat oleh `buildContext()` di `src/lib/message-parser.js`.

| Property | Tipe | Keterangan |
|----------|------|------------|
| `id` | string | ID pesan |
| `remoteJid` | string | JID chat tujuan balasan |
| `senderJid` | string | JID pengirim |
| `pushName` | string | Nama display WA |
| `body` | string | Isi teks pesan |
| `args` | string[] | Argumen setelah command |
| `command` | string | Nama command (lowercase) |
| `prefix` | string | Prefix yang dipakai user (`.` `/` `!`) |
| `isCommand` | boolean | Apakah pesan adalah command |
| `isGroup` | boolean | Chat grup |
| `isPrivate` | boolean | Chat pribadi |
| `isSelfChat` | boolean | Chat ke nomor sendiri |
| `isOwner` | boolean | Pengirim = owner (config owner.number) |
| `isFromMe` | boolean | Pesan dari bot/account sendiri |
| `isNewsletter` | boolean | Saluran/newsletter |
| `isStory` | boolean | Status/story |
| `isBroadcast` | boolean | Broadcast list |
| `messageType` | string | conversation, imageMessage, dll. |
| `raw` | object | Pesan mentah Baileys (untuk quote reply) |
| `runtime` | object | `{ mode: 'public' \| 'self', ... }` |
| `startedAt` | number | Timestamp bot start (untuk uptime) |

**Parse command:** user kirim `.ping` → `prefix='.'`, `command='ping'`, `args=[]`  
User kirim `.giveaway https://link.com` → `args=['https://link.com']`

---

## 7. Kirim balasan

### Teks biasa (disarankan)

```javascript
const { sendBotReply } = require('../../lib/messaging');

await sendBotReply(kurrxd, ctx, { text: 'Hello!' });
```

- Otomatis quote pesan user (kecuali self-chat)
- Footer kredit hanya jika pakai `sendBotText` atau `out()` dari formatter

### Teks + footer resmi

```javascript
const { sendBotText, replyOptions } = require('../../lib/messaging');

await sendBotText(kurrxd, ctx.remoteJid, teks, replyOptions(ctx));
```

### Media

```javascript
await sendBotReply(kurrxd, ctx, {
  image: bufferAtauPath,
  caption: 'Caption di sini'
});
```

### Reply media user (contoh: sticker)

Lihat `src/commands/general/sticker.js` + `src/lib/quoted-media.js`

---

## 8. Style tampilan (formatter)

Bot pakai style box Unicode. Helper di `src/lib/formatter.js`:

```
╭──❍「 *JUDUL* 」❍
├ *Label* : value
╰──────❍
```

Untuk command baru, buat fungsi di `formatter.js`:

```javascript
function buildGiveawayText({ result }) {
  const lines = buildBoxSection('GIVEAWAY', [
    formatRow('Hasil', result)
  ]);
  return out(lines.join('\n')); // out() = tambah footer KurrXd Official
}
```

Export di `module.exports`, panggil dari command handler.

**Menu `.help`:** otomatis list command dari `registry.js` — tidak perlu edit `help.js` kecuali logic khusus.

---

## 9. Permission & akses

### Owner only

Set `ownerOnly: true` di registry → dicek di `src/lib/permissions.js`.

### Mode private (self)

Owner jalankan `.self` → hanya owner bisa pakai command.  
Balik ke public: `.public`

### Grup wajib prefix

`config.json`:
```json
"group": { "requirePrefix": true }
```

Di grup, pesan tanpa prefix **diabaikan** (bukan command).

### Cek manual di handler

```javascript
if (!ctx.isGroup) { /* tolak */ }
if (!ctx.isOwner) { /* tolak */ }
```

---

## 10. Simpan data user/grup

DB JSON di `data/` via `src/lib/db/`.

```javascript
const { getUser, registerUser } = require('../../lib/db');
const { getWelcomeSetting, setWelcomeEnabled } = require('../../lib/db');
```

- User otomatis terdaftar saat kirim pesan (`message.js`)
- Tambah field baru → edit `src/lib/db/users.js` atau buat file baru di `src/lib/db/`

---

## 11. Integrasi AI / API / Cloud

**Pola yang benar:** logic API di `src/lib/`, command cuma orchestrator.

```
src/lib/ai.js          ← panggil OpenAI/Gemini
src/lib/giveaway.js    ← logic cek giveaway
src/commands/general/giveaway.js  ← terima args, panggil lib, balas
```

### Contoh `src/lib/ai.js`

```javascript
'use strict';

async function askAI(prompt, apiKey) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }]
    })
  });

  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'Tidak ada jawaban.';
}

module.exports = { askAI };
```

### API key — jangan hardcode

Opsi 1 — environment variable:
```javascript
const apiKey = process.env.OPENAI_API_KEY;
```

Opsi 2 — config (jangan commit key ke git publik):
```json
"ai": {
  "openaiKey": "sk-..."
}
```

---

## 12. Contoh lengkap: command `echo`

### `src/commands/general/echo.js`

```javascript
'use strict';

const { sendBotReply } = require('../../lib/messaging');

module.exports = async function echo(ctx, kurrxd) {
  const text = ctx.args.join(' ').trim() || '(kosong)';
  await sendBotReply(kurrxd, ctx, { text: `Echo: ${text}` });
};
```

### `registry.js` — tambah:

```javascript
{
  name: 'echo',
  aliases: [],
  category: 'general',
  ownerOnly: false,
  description: 'Ulangi teks'
}
```

### `handlers.js` — tambah:

```javascript
echo: require('./general/echo'),
```

### `config.json` — tambah:

```json
"echo": true
```

---

## 13. File yang JANGAN diubah sembarangan

| Area | File | Alasan |
|------|------|--------|
| Session/auth | `src/handlers/connection/`, `session/` | Bisa logout / QR ulang |
| Credit resmi | `src/lib/credit.js` | Hardcoded developer |
| node_modules | `@Kurniaharun/Baileys` | Patch manual hilang saat npm install |
| Dedup pesan | `src/lib/message-dedup.js` | Cegah command double |

Kalau AI suggest edit file connection atau Baileys — **tanya dulu** apakah benar perlu.

---

## 14. Debug & troubleshooting

| Masalah | Cek |
|---------|-----|
| Command tidak jalan | Prefix benar? Feature `true` di config? Restart bot? |
| Command dobel | Sudah ada dedup di `message-dedup.js` |
| Grup tidak respon | Harus pakai prefix di grup |
| Error handler | Log: `logs/xdbotz.log` |
| Syntax error | `node --check src/commands/general/nama.js` |

---

## 15. Konvensi kode (WAJIB diikuti AI)

- **CommonJS:** `require()` / `module.exports` (bukan ES import)
- **`'use strict';`** di baris pertama setiap file
- **Satu command = satu file** di `commands/`
- **Logic berat** → `src/lib/`, bukan di handler
- **Minimal diff** — jangan refactor file lain tanpa diminta
- **Bahasa UI bot:** Indonesia
- **Footer bot:** pakai `out()` atau `sendBotText` untuk teks resmi

---

## 16. Contoh jawaban user ke AI (saat ditanya fitur)

User **tidak perlu** format khusus — jelasin biasa aja. Contoh:

```
Mau command .giveaway
Alias: gw
Fungsi: user kirim link, bot cek apakah giveaway valid atau hoax
Pakai OpenAI, key nanti dari env
Owner only dulu buat tes
Balasan pakai box formatter kayak menu help
```

Atau lebih singkat:

```
.bantuan — jawab pertanyaan random pakai AI, prefix titik, semua user boleh
```

AI cloud yang urus sisanya (file, registry, config) sesuai panduan di bawah.

---

## 17. Prompt template (kalau perlu)

### Mulai sesi baru (upload MD)

```
Upload: CARA-TAMBAH-FITUR.md
Tanyain dulu fitur apa yang mau saya buat. Jangan coding dulu.
```

### Setelah user jelasin fitur

```
Oke, buat fitur yang tadi saya jelaskan.
Ikuti CARA-TAMBAH-FITUR.md — checklist 4 langkah + konvensi kode.
Kasih daftar file yang diubah + cara test.
```

### Integrasi AI/API (user sudah jelasin)

```
Buat fitur AI sesuai penjelasan saya tadi.
Logic API di src/lib/, command di src/commands/.
API key dari process.env — jangan hardcode.
ownerOnly: true untuk tes awal.
```

### Fix bug (bukan fitur baru)

```
Ikuti CARA-TAMBAH-FITUR.md.
Bug: <jelaskan>
Log: <paste dari logs/xdbotz.log>
Fix minimal, jangan refactor file lain.
```

---

## 18. Command yang sudah ada (referensi)

| Command | Alias | Kategori | Keterangan |
|---------|-------|----------|------------|
| ping | pong, speed | general | Latency & uptime |
| help | menu, bantuan | general | Menu info bot |
| owner | creator, dev… | general | Kontak owner |
| credit | c, cred… | general | Credit developer |
| sticker | s, stiker… | general | Reply media → stiker |
| welcome | welkom | group | Sambutan member on/off |
| self | private | owner | Mode private |
| public | pub | owner | Mode public |

**Contoh paling simpel:** `src/commands/general/ping.js`  
**Contoh media/reply:** `src/commands/general/sticker.js`  
**Contoh grup + admin:** `src/commands/group/welcome.js`

---

## 19. Versi dokumen

- Bot: XDBOTZ MD 1.0.0
- Prefix: `/` `.` `!`
- Node: ≥ 20
- Terakhir update: Juni 2026

---

## Ringkasan

| Langkah | Siapa | Apa |
|---------|-------|-----|
| 1 | Kamu | Upload `CARA-TAMBAH-FITUR.md` ke AI cloud |
| 2 | AI cloud | Tanya mau fitur apa |
| 3 | Kamu | Jelasin sendiri (command, fungsi, akses) |
| 4 | AI cloud | Bikin kode sesuai panduan ini |
| 5 | Kamu | Copy ke project, restart, tes |
| 6 | (Opsional) | Cursor / dev lokal kalau perlu fix |

*File ini cukup di-upload ulang setiap sesi baru di AI cloud — tidak perlu baca full script.*
