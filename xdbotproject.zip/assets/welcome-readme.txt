Welcome memakai foto profil (PP) member yang baru join.
Tidak perlu simpan gambar di folder assets.

Kalau member tidak punya PP, bot kirim teks sambutan saja.
